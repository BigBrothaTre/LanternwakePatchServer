local ADDON_NAME = "LanternwakePicker"

local pickerFrame
local activeDisciplineKey = "veil"
local activeRowKey = "row1"
local cardFrames = {}

local disciplineData = {
    veil = {
        buttonText = "Veil",
        rows = {
            row1 = {
                title = "Choose Your Track",
                subtitle = "Veil Stalker Row 1 - The Stalker's Approach",
                help = "Requires level 2.",
                choices = {
                    { title = "Blackfang Shot", subtitle = "Predator Shot", icon = "Interface\\Icons\\Ability_Hunter_ChimeraShot2", description = "Strike from range with a shadowed predator shot.", command = "#lw tome veil blackfang_shot" },
                    { title = "Emberfang Shot", subtitle = "Volatile Shot", icon = "Interface\\Icons\\Ability_Hunter_ExplosiveShot", description = "Fire a burning shot that erupts into pressure over time.", command = "#lw tome veil emberfang_shot" },
                    { title = "Steady Aim", subtitle = "Reliable Shot", icon = "Interface\\Icons\\Ability_Hunter_SteadyShot", description = "Choose a disciplined shot style built around stable ranged pressure.", command = "#lw tome veil steady_aim" }
                }
            },
            row2 = {
                title = "Choose Your Field",
                subtitle = "Veil Stalker Row 2 - The Stalker's Field",
                help = "Requires level 3 and a learned Row 1 Veil spell.",
                choices = {
                    { title = "Black Arrow", subtitle = "Shadow Pressure", icon = "Interface\\Icons\\Spell_Shadow_PainSpike", description = "Mark prey with shadow pressure and delayed punishment.", command = "#lw tome veil black_arrow" },
                    { title = "Serpent Sting", subtitle = "Venom Pressure", icon = "Interface\\Icons\\Ability_Hunter_Quickshot", description = "Keep venom working while you control the field.", command = "#lw tome veil serpent_sting" },
                    { title = "Volley", subtitle = "Area Pressure", icon = "Interface\\Icons\\Ability_Marksmanship", description = "Rain arrows over clustered enemies and dangerous ground.", command = "#lw tome veil volley" }
                }
            },
            row3 = {
                title = "Choose Your Snare",
                subtitle = "Veil Stalker Row 3 - The Stalker's Snare",
                help = "Requires level 4 and a learned Row 2 Veil spell.",
                choices = {
                    { title = "Wyvern Sting", subtitle = "Sleep Control", icon = "Interface\\Icons\\INV_Spear_02", description = "Drop a dangerous target into a venomous sleep.", command = "#lw tome veil wyvern_sting" },
                    { title = "Blackout Shot", subtitle = "Caster Denial", icon = "Interface\\Icons\\Ability_TheBlackArrow", description = "Silence enemy casters before their magic blooms.", command = "#lw tome veil blackout_shot" },
                    { title = "Scatter the Trail", subtitle = "Emergency Spacing", icon = "Interface\\Icons\\Ability_GolemStormBolt", description = "Disorient a threat and reclaim room to breathe.", command = "#lw tome veil scatter_the_trail" }
                }
            },
            row4 = {
                title = "Choose Your Escape",
                subtitle = "Veil Stalker Row 4 - The Stalker's Escape",
                help = "Requires level 5 and a learned Row 3 Veil spell.",
                choices = {
                    { title = "Deadfall Feint", subtitle = "Threat Break", icon = "Interface\\Icons\\Ability_Rogue_FeignDeath", description = "Trick enemies into losing your trail.", command = "#lw tome veil deadfall_feint" },
                    { title = "Hardstep", subtitle = "Reposition", icon = "Interface\\Icons\\Ability_Rogue_Trip", description = "Kick away from danger and reset your spacing.", command = "#lw tome veil hardstep" },
                    { title = "Last Veil", subtitle = "Survival Wall", icon = "Interface\\Icons\\Ability_Whirlwind", description = "Raise a final defensive veil when pressure peaks.", command = "#lw tome veil last_veil" }
                }
            },
            row5 = {
                title = "Choose Your Claim",
                subtitle = "Veil Stalker Row 5 - The Stalker's Claim",
                help = "Requires level 7 and a learned Row 4 Veil spell.",
                choices = {
                    { title = "Heartpiercer Shot", subtitle = "Execution", icon = "Interface\\Icons\\Ability_Hunter_Assassinate2", description = "End wounded prey with a decisive killing shot.", command = "#lw tome veil heartpiercer_shot" },
                    { title = "Blackroad Tempo", subtitle = "Burst Rhythm", icon = "Interface\\Icons\\Ability_Hunter_RunningShot", description = "Enter a rapid firing rhythm when the road opens.", command = "#lw tome veil blackroad_tempo" },
                    { title = "Trueshot Claim", subtitle = "Group Pressure", icon = "Interface\\Icons\\Ability_Trueshot", description = "Claim the field with a disciplined pressure aura.", command = "#lw tome veil trueshot_claim" }
                }
            }
        }
    },

    arcanist = {
        buttonText = "Arcanist",
        rows = {
            row1 = {
                title = "Choose Your Formula",
                subtitle = "Relic Arcanist Row 1 - The First Arcane Lesson",
                help = "Requires level 2.",
                choices = {
                    { title = "Pyroblast", subtitle = "Heavy Fire Cast", icon = "Interface\\Icons\\Spell_Fire_Fireball02", description = "Commit to a slow, brutal fire formula.", command = "#lw tome arcanist pyroblast" },
                    { title = "Arcane Blast", subtitle = "Stacking Arcane Force", icon = "Interface\\Icons\\Spell_Arcane_Blast", description = "Build pressure through repeated arcane impact.", command = "#lw tome arcanist arcane_blast" },
                    { title = "Arcane Missiles", subtitle = "Channelled Barrage", icon = "Interface\\Icons\\Spell_Nature_StarFall", description = "Channel a reliable stream of arcane missiles.", command = "#lw tome arcanist arcane_missiles" }
                }
            },
            row2 = {
                title = "Choose Your Tempo",
                subtitle = "Relic Arcanist Row 2 - The Second Arcane Lesson",
                help = "Requires level 3 and a learned Row 1 Arcanist spell.",
                choices = {
                    { title = "Combustion", subtitle = "Fire Surge", icon = "Interface\\Icons\\Spell_Fire_SealOfFire", description = "Lean into volatile fire windows.", command = "#lw tome arcanist combustion" },
                    { title = "Arcane Power", subtitle = "Arcane Surge", icon = "Interface\\Icons\\Spell_Nature_Lightning", description = "Trade restraint for a burst of raw arcane force.", command = "#lw tome arcanist arcane_power" },
                    { title = "Icy Veins", subtitle = "Cold Acceleration", icon = "Interface\\Icons\\Spell_Frost_ColdHearted", description = "Accelerate casting through a cold focus state.", command = "#lw tome arcanist icy_veins" }
                }
            },
            row3 = {
                title = "Choose Your Control",
                subtitle = "Relic Arcanist Row 3 - The Third Arcane Lesson",
                help = "Requires level 4 and a learned Row 2 Arcanist spell.",
                choices = {
                    { title = "Polymorph", subtitle = "Single Target Control", icon = "Interface\\Icons\\Spell_Nature_Polymorph", description = "Remove one threat from the board.", command = "#lw tome arcanist polymorph" },
                    { title = "Dragon's Breath", subtitle = "Cone Disorient", icon = "Interface\\Icons\\INV_Misc_Head_Dragon_01", description = "Disorient enemies in front of you with burning force.", command = "#lw tome arcanist dragons_breath" },
                    { title = "Frost Nova", subtitle = "Rooting Sigil", icon = "Interface\\Icons\\Spell_Frost_FrostNova", description = "Lock nearby enemies in place and reclaim spacing.", command = "#lw tome arcanist frost_nova" }
                }
            },
            row4 = {
                title = "Choose Your Ward",
                subtitle = "Relic Arcanist Row 4 - The Fourth Arcane Lesson",
                help = "Requires level 5 and a learned Row 3 Arcanist spell.",
                choices = {
                    { title = "Ice Block", subtitle = "Absolute Guard", icon = "Interface\\Icons\\Spell_Frost_Frost", description = "Seal yourself in ice to survive lethal pressure.", command = "#lw tome arcanist ice_block" },
                    { title = "Mirror Image", subtitle = "Decoy Formula", icon = "Interface\\Icons\\Spell_Magic_LesserInvisibilty", description = "Split attention with unstable arcane doubles.", command = "#lw tome arcanist mirror_image" },
                    { title = "Mana Shield", subtitle = "Mana Ward", icon = "Interface\\Icons\\Spell_Shadow_DetectLesserInvisibility", description = "Spend mana to blunt incoming harm.", command = "#lw tome arcanist mana_shield" }
                }
            },
            row5 = {
                title = "Choose Your Tactic",
                subtitle = "Relic Arcanist Row 5 - The Fifth Arcane Lesson",
                help = "Requires level 7 and a learned Row 4 Arcanist spell.",
                choices = {
                    { title = "Counterspell", subtitle = "Caster Break", icon = "Interface\\Icons\\Spell_Frost_IceShock", description = "Shatter an enemy cast before it blooms.", command = "#lw tome arcanist counterspell" },
                    { title = "Spellsteal", subtitle = "Formula Theft", icon = "Interface\\Icons\\Spell_Arcane_Arcane02", description = "Rip useful magic from enemies and turn it to your purpose.", command = "#lw tome arcanist spellsteal" },
                    { title = "Invisibility", subtitle = "Escape Veil", icon = "Interface\\Icons\\Ability_Mage_Invisibility", description = "Slip out of danger through a fading arcane veil.", command = "#lw tome arcanist invisibility" }
                }
            }
        }
    },

    ruin = {
        buttonText = "Ruin",
        rows = {
            row1 = {
                title = "Choose Your Scar",
                subtitle = "Ruin Seeker Row 1 - The First Scar",
                help = "Requires level 2.",
                choices = {
                    { title = "Ruinstrike", subtitle = "Mortal Wound", icon = "Interface\\Icons\\Ability_Warrior_SavageBlow", description = "Carve a brutal strike that wounds the enemy's recovery.", command = "#lw tome ruin ruinstrike" },
                    { title = "Deathblow", subtitle = "Execution Strike", icon = "Interface\\Icons\\Ability_Warrior_DecisiveStrike", description = "Choose the finishing instinct: end weakened enemies with force.", command = "#lw tome ruin deathblow" },
                    { title = "Bloodthirst", subtitle = "Aggressive Sustain", icon = "Interface\\Icons\\Spell_Nature_BloodLust", description = "Feed your assault through violent momentum and self-sustain.", command = "#lw tome ruin bloodthirst" }
                }
            },
            row2 = {
                title = "Choose Your Pressure",
                subtitle = "Ruin Seeker Row 2 - The Second Scar",
                help = "Requires level 3 and a learned Row 1 Ruin spell.",
                choices = {
                    { title = "Ruin's Rend", subtitle = "Bleeding Pressure", icon = "Interface\\Icons\\Ability_Gouge", description = "Open a wound that keeps working while you fight.", command = "#lw tome ruin ruins_rend" },
                    { title = "Ruin's Sweep", subtitle = "Cleave Rhythm", icon = "Interface\\Icons\\Ability_Rogue_SliceDice", description = "Carry your weapon pressure through nearby enemies.", command = "#lw tome ruin ruins_sweep" },
                    { title = "Ruin's Thunder", subtitle = "Area Disruption", icon = "Interface\\Icons\\Spell_Nature_ThunderClap", description = "Break enemy rhythm with a punishing thunderclap.", command = "#lw tome ruin ruins_thunder" }
                }
            },
            row3 = {
                title = "Choose Your Break",
                subtitle = "Ruin Seeker Row 3 - The Third Scar",
                help = "Requires level 4 and a learned Row 2 Ruin spell.",
                choices = {
                    { title = "Ruin's Charge", subtitle = "Engage", icon = "Interface\\Icons\\Ability_Warrior_Charge", description = "Crash into battle and decide where the fight begins.", command = "#lw tome ruin ruins_charge" },
                    { title = "Ruin's Stun", subtitle = "Hard Control", icon = "Interface\\Icons\\Ability_ThunderBolt", description = "Crush a target's momentum with a stunning blow.", command = "#lw tome ruin ruins_stun" },
                    { title = "Ruin's Hamstring", subtitle = "Snare", icon = "Interface\\Icons\\Ability_ShockWave", description = "Cut movement and keep prey inside your reach.", command = "#lw tome ruin ruins_hamstring" }
                }
            },
            row4 = {
                title = "Choose Your Endurance",
                subtitle = "Ruin Seeker Row 4 - The Fourth Scar",
                help = "Requires level 5 and a learned Row 3 Ruin spell.",
                choices = {
                    { title = "Ruin's Stand", subtitle = "Last Stand", icon = "Interface\\Icons\\Spell_Holy_AshesToAshes", description = "Refuse collapse when the fight turns against you.", command = "#lw tome ruin ruins_stand" },
                    { title = "Berserker Rage", subtitle = "Fearless Surge", icon = "Interface\\Icons\\Spell_Nature_AncestralGuardian", description = "Break fear and fuel yourself through fury.", command = "#lw tome ruin berserker_rage" },
                    { title = "Blood Rage", subtitle = "Pain to Power", icon = "Interface\\Icons\\Ability_Racial_BloodRage", description = "Spend blood to wake the engine of rage.", command = "#lw tome ruin blood_rage" }
                }
            },
            row5 = {
                title = "Choose Your Ruin",
                subtitle = "Ruin Seeker Row 5 - The Fifth Scar",
                help = "Requires level 7 and a learned Row 4 Ruin spell.",
                choices = {
                    { title = "Shockwave", subtitle = "Frontal Rupture", icon = "Interface\\Icons\\Ability_Warrior_Shockwave", description = "Break enemies in front of you with a violent shockwave.", command = "#lw tome ruin shockwave" },
                    { title = "Death Wish", subtitle = "Risk Surge", icon = "Interface\\Icons\\Spell_Shadow_DeathPact", description = "Trade safety for a brutal window of power.", command = "#lw tome ruin death_wish" },
                    { title = "Bladestorm", subtitle = "Weapon Tempest", icon = "Interface\\Icons\\Ability_Warrior_Bladestorm", description = "Become the center of a cutting storm.", command = "#lw tome ruin bladestorm" }
                }
            }
        }
    },

    ash = {
        buttonText = "Ash",
        rows = {
            row1 = {
                title = "Choose Your Remedy",
                subtitle = "Ash Medic Row 1 - The Medic's Touch",
                help = "Requires level 2.",
                choices = {
                    { title = "Flash Heal", subtitle = "Quick Remedy", icon = "Interface\\Icons\\Spell_Holy_FlashHeal", description = "Choose fast direct recovery for sharp danger moments.", command = "#lw tome ash flash_heal" },
                    { title = "Renew", subtitle = "Sustained Dressing", icon = "Interface\\Icons\\Spell_Holy_Renew", description = "Keep recovery working over time while the fight moves.", command = "#lw tome ash renew" },
                    { title = "Power Word: Shield", subtitle = "Ash Ward", icon = "Interface\\Icons\\Spell_Holy_PowerWordShield", description = "Prevent harm before the wound opens.", command = "#lw tome ash power_word_shield" }
                }
            },
            row2 = {
                title = "Choose Your Strike",
                subtitle = "Ash Medic Row 2 - The Medic's Strike",
                help = "Requires level 3 and a learned Row 1 Ash spell.",
                choices = {
                    { title = "Mind Blast", subtitle = "Psychic Impact", icon = "Interface\\Icons\\Spell_Shadow_UnholyFrenzy", description = "Deliver a focused burst of hostile thought.", command = "#lw tome ash mind_blast" },
                    { title = "Holy Fire", subtitle = "Ashfire Brand", icon = "Interface\\Icons\\Spell_Holy_SearingLight", description = "Burn the target with sacred ash and pressure over time.", command = "#lw tome ash holy_fire" },
                    { title = "Shadow Word: Pain", subtitle = "Ashen Rot", icon = "Interface\\Icons\\Spell_Shadow_ShadowWordPain", description = "Leave a lingering wound that keeps ticking.", command = "#lw tome ash shadow_word_pain" }
                }
            },
            row3 = {
                title = "Choose Your Presence",
                subtitle = "Ash Medic Row 3 - The Medic's Presence",
                help = "Requires level 4 and a learned Row 2 Ash spell.",
                choices = {
                    { title = "Psychic Scream", subtitle = "Panic Break", icon = "Interface\\Icons\\Spell_Shadow_PsychicScream", description = "Force nearby enemies away when the line collapses.", command = "#lw tome ash psychic_scream" },
                    { title = "Silence", subtitle = "Caster Denial", icon = "Interface\\Icons\\Spell_Shadow_ImpPhaseShift", description = "Cut off a dangerous spell before it lands.", command = "#lw tome ash silence" },
                    { title = "Shackle Undead", subtitle = "Reliquary Control", icon = "Interface\\Icons\\Spell_Nature_Slow", description = "Bind undead threats and buy the group time.", command = "#lw tome ash shackle_undead" }
                }
            },
            row4 = {
                title = "Choose Your Survival",
                subtitle = "Ash Medic Row 4 - The Medic's Survival",
                help = "Requires level 5 and a learned Row 3 Ash spell.",
                choices = {
                    { title = "Pain Suppression", subtitle = "Emergency Ward", icon = "Interface\\Icons\\Spell_Holy_PainSupression", description = "Blunt incoming harm during a crisis window.", command = "#lw tome ash pain_suppression" },
                    { title = "Dispersion", subtitle = "Ash Veil", icon = "Interface\\Icons\\Spell_Shadow_Dispersion", description = "Scatter into shadowed ash and survive pressure.", command = "#lw tome ash dispersion" },
                    { title = "Guardian Spirit", subtitle = "Mercy Sign", icon = "Interface\\Icons\\Spell_Holy_GuardianSpirit", description = "Place a saving presence over a fragile life.", command = "#lw tome ash guardian_spirit" }
                }
            },
            row5 = {
                title = "Choose Your Field",
                subtitle = "Ash Medic Row 5 - The Medic's Field",
                help = "Requires level 7 and a learned Row 4 Ash spell.",
                choices = {
                    { title = "Prayer of Mending", subtitle = "Jumping Remedy", icon = "Interface\\Icons\\Spell_Holy_PrayerOfMendingtga", description = "Send a remedy that moves where wounds appear.", command = "#lw tome ash prayer_of_mending" },
                    { title = "Circle of Healing", subtitle = "Group Recovery", icon = "Interface\\Icons\\Spell_Holy_CircleOfRenewal", description = "Stabilize nearby allies with a fast healing circle.", command = "#lw tome ash circle_of_healing" },
                    { title = "Divine Hymn", subtitle = "Field Invocation", icon = "Interface\\Icons\\Spell_Holy_DivineHymn", description = "Channel a major recovery moment for the expedition.", command = "#lw tome ash divine_hymn" }
                }
            }
        }
    },

    warden = {
        buttonText = "Warden",
        rows = {
            row1 = {
                title = "Choose Your Strike",
                subtitle = "Lantern Warden Row 1 - The Warden's Strike",
                help = "Requires level 2.",
                choices = {
                    { title = "Crusader Strike", subtitle = "Oath Strike", icon = "Interface\\Icons\\Spell_Holy_CrusaderStrike", description = "Strike with a direct oathbound weapon blow.", command = "#lw tome warden crusader_strike" },
                    { title = "Divine Storm", subtitle = "Radiant Cleave", icon = "Interface\\Icons\\Ability_Paladin_DivineStorm", description = "Turn your weapon into a sweeping burst of guarded light.", command = "#lw tome warden divine_storm" },
                    { title = "Avenger's Shield", subtitle = "Thrown Ward", icon = "Interface\\Icons\\Spell_Holy_AvengersShield", description = "Hurl your shield through danger and break enemy momentum.", command = "#lw tome warden avengers_shield" }
                }
            },
            row2 = {
                title = "Choose Your Judgment",
                subtitle = "Lantern Warden Row 2 - The Warden's Judgment",
                help = "Requires level 3 and a learned Row 1 Warden spell.",
                choices = {
                    { title = "Exorcism", subtitle = "Hollowlight Rebuke", icon = "Interface\\Icons\\Spell_Holy_Excorcism_02", description = "Burn hostile forces with a focused warding strike.", command = "#lw tome warden exorcism" },
                    { title = "Consecration", subtitle = "Consecrated Ground", icon = "Interface\\Icons\\Spell_Holy_InnerFire", description = "Claim the ground around you with persistent holy pressure.", command = "#lw tome warden consecration" },
                    { title = "Judgement of Light", subtitle = "Mercy Verdict", icon = "Interface\\Icons\\Spell_Holy_RighteousFury", description = "Mark an enemy so attacks against it return recovery.", command = "#lw tome warden judgement_of_light" }
                }
            },
            row3 = {
                title = "Choose Your Command",
                subtitle = "Lantern Warden Row 3 - The Warden's Command",
                help = "Requires level 4 and a learned Row 2 Warden spell.",
                choices = {
                    { title = "Hammer of Justice", subtitle = "Hard Stop", icon = "Interface\\Icons\\Spell_Holy_SealOfMight", description = "Bring a dangerous target to a halt.", command = "#lw tome warden hammer_of_justice" },
                    { title = "Repentance", subtitle = "Mercy Bind", icon = "Interface\\Icons\\Spell_Holy_PrayerOfHealing", description = "Remove one threat from the fight with a focused command.", command = "#lw tome warden repentance" },
                    { title = "Holy Wrath", subtitle = "Undead Breaker", icon = "Interface\\Icons\\Spell_Holy_Excorcism", description = "Punish undead pressure with a radiant field burst.", command = "#lw tome warden holy_wrath" }
                }
            },
            row4 = {
                title = "Choose Your Vow",
                subtitle = "Lantern Warden Row 4 - The Shieldbearer's Vow",
                help = "Requires level 5 and a learned Row 3 Warden spell.",
                choices = {
                    { title = "Holy Shield", subtitle = "Shield Oath", icon = "Interface\\Icons\\Spell_Holy_BlessingOfProtection", description = "Turn blocking into a punishing defensive rhythm.", command = "#lw tome warden holy_shield" },
                    { title = "Divine Protection", subtitle = "Emergency Ward", icon = "Interface\\Icons\\Spell_Holy_Restoration", description = "Reduce incoming harm when the line is breaking.", command = "#lw tome warden divine_protection" },
                    { title = "Lay on Hands", subtitle = "Last Mercy", icon = "Interface\\Icons\\Spell_Holy_LayOnHands", description = "Spend a rare miracle to save a life from the edge.", command = "#lw tome warden lay_on_hands" }
                }
            },
            row5 = {
                title = "Choose Your Charge",
                subtitle = "Lantern Warden Row 5 - The Roadwarden's Charge",
                help = "Requires level 7 and a learned Row 4 Warden spell.",
                choices = {
                    { title = "Hand of Freedom", subtitle = "Road Unbound", icon = "Interface\\Icons\\Spell_Holy_SealOfValor", description = "Break movement control and keep the road open.", command = "#lw tome warden hand_of_freedom" },
                    { title = "Sacred Shield", subtitle = "Lantern Ward", icon = "Interface\\Icons\\Ability_Paladin_BlessedMending", description = "Wrap an ally in a recurring protective ward.", command = "#lw tome warden sacred_shield" },
                    { title = "Avenging Wrath", subtitle = "Oathflare", icon = "Interface\\Icons\\Spell_Holy_AvengineWrath", description = "Ignite a short window of decisive holy force.", command = "#lw tome warden avenging_wrath" }
                }
            }
        }
    }
}

local rowOrder = { "row1", "row2", "row3", "row4", "row5" }

local function Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cffb48cffLanternwake Picker:|r " .. msg)
end

local function HideCards()
    for _, card in ipairs(cardFrames) do
        card:Hide()
    end
    cardFrames = {}
end

local function AddSpellTooltip(frame, data)
    frame:EnableMouse(true)
    frame:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(data.title or "Spell Choice", 1, 0.82, 0)

        if data.subtitle then
            GameTooltip:AddLine(data.subtitle, 0.75, 0.75, 0.75, true)
        end

        GameTooltip:AddLine(" ", 1, 1, 1, true)

        if data.description then
            GameTooltip:AddLine(data.description, 1, 1, 1, true)
        end

        GameTooltip:AddLine(" ", 1, 1, 1, true)
        GameTooltip:AddLine("Role: " .. (data.role or data.subtitle or "Specialized tool"), 0.45, 0.75, 1, true)
        GameTooltip:AddLine("Best used for: " .. (data.best or "Players who want this row's " .. (data.subtitle or "specialized") .. " option."), 0.55, 1, 0.55, true)
        GameTooltip:AddLine("Tradeoff: Choosing this locks the other two spells in this row.", 1, 0.55, 0.45, true)

        if data.requirement then
            GameTooltip:AddLine("Requirement: " .. data.requirement, 1, 0.82, 0.35, true)
        end

        GameTooltip:AddLine(" ", 1, 1, 1, true)
        GameTooltip:AddLine("Choose gives a tome. Use the tome to learn this spell.", 0.8, 0.8, 1, true)

        if data.command then
            GameTooltip:AddLine(data.command, 0.5, 0.5, 0.5, true)
        end

        GameTooltip:Show()
    end)

    frame:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
end
local function CreateCard(parent, index, data)
    local card = CreateFrame("Frame", nil, parent)
    card:SetSize(330, 330)
    card:SetPoint("TOPLEFT", parent, "TOPLEFT", 60 + ((index - 1) * 380), -180)

    card:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 24,
        insets = { left = 8, right = 8, top = 8, bottom = 8 }
    })
    card:SetBackdropColor(0.04, 0.035, 0.03, 0.96)

    local title = card:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", card, "TOP", 0, -26)
    title:SetText(data.title)

    local subtitle = card:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    subtitle:SetPoint("TOP", title, "BOTTOM", 0, -8)
    subtitle:SetText(data.subtitle)

    local icon = card:CreateTexture(nil, "ARTWORK")
    icon:SetSize(62, 62)
    icon:SetPoint("TOP", subtitle, "BOTTOM", 0, -24)
    icon:SetTexture(data.icon)

    local desc = card:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    desc:SetPoint("TOPLEFT", card, "TOPLEFT", 30, -165)
    desc:SetPoint("TOPRIGHT", card, "TOPRIGHT", -30, -165)
    desc:SetJustifyH("CENTER")
    desc:SetText(data.description)

    card.commandPreview = card:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    card.commandPreview:SetPoint("BOTTOM", card, "BOTTOM", 0, 62)
    card.commandPreview:SetText(data.command or "")
    card.hoverLayer = CreateFrame("Button", nil, card)
    card.hoverLayer:SetPoint("TOPLEFT", card, "TOPLEFT", 0, 0)
    card.hoverLayer:SetPoint("BOTTOMRIGHT", card, "BOTTOMRIGHT", 0, 82)
    card.hoverLayer:SetFrameLevel(card:GetFrameLevel() + 5)
    card.hoverLayer:EnableMouse(true)
    AddSpellTooltip(card.hoverLayer, data)


    local button = CreateFrame("Button", nil, card, "UIPanelButtonTemplate")
    button:SetSize(190, 30)
    button:SetPoint("BOTTOM", card, "BOTTOM", 0, 26)
    button:SetText("Choose")
    button:SetScript("OnClick", function()
        SendChatMessage(data.command, "SAY")
        Print("Requested: " .. data.command)
        if pickerFrame then
            pickerFrame:Hide()
        end
    end)

    table.insert(cardFrames, card)
end

local function RenderRow(disciplineKey, rowKey)
    disciplineKey = disciplineKey or activeDisciplineKey or "veil"
    rowKey = rowKey or activeRowKey or "row1"

    if not disciplineData[disciplineKey] then
        disciplineKey = "veil"
    end

    if not disciplineData[disciplineKey].rows[rowKey] then
        rowKey = "row1"
    end

    activeDisciplineKey = disciplineKey
    activeRowKey = rowKey

    local row = disciplineData[disciplineKey].rows[rowKey]

    HideCards()

    pickerFrame.header:SetText(row.title)
    pickerFrame.subheader:SetText(row.subtitle)
    pickerFrame.helpText:SetText(row.help)

    for i, data in ipairs(row.choices) do
        data.requirement = row.help
        CreateCard(pickerFrame, i, data)
    end
end

local function CreatePicker()
    pickerFrame = CreateFrame("Frame", "LanternwakePickerFrame", UIParent)
    pickerFrame:SetSize(1240, 620)
    pickerFrame:SetPoint("CENTER")
    pickerFrame:SetFrameStrata("DIALOG")
    pickerFrame:EnableMouse(true)
    pickerFrame:SetMovable(true)
    pickerFrame:RegisterForDrag("LeftButton")
    pickerFrame:SetScript("OnDragStart", pickerFrame.StartMoving)
    pickerFrame:SetScript("OnDragStop", pickerFrame.StopMovingOrSizing)

    pickerFrame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 32,
        insets = { left = 10, right = 10, top = 10, bottom = 10 }
    })
    pickerFrame:SetBackdropColor(0.02, 0.018, 0.015, 0.98)

    pickerFrame.header = pickerFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    pickerFrame.header:SetPoint("TOP", pickerFrame, "TOP", 0, -34)

    pickerFrame.subheader = pickerFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    pickerFrame.subheader:SetPoint("TOP", pickerFrame.header, "BOTTOM", 0, -8)

    pickerFrame.helpText = pickerFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    pickerFrame.helpText:SetPoint("TOP", pickerFrame.subheader, "BOTTOM", 0, -6)

    pickerFrame.footerText = pickerFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    pickerFrame.footerText:SetPoint("BOTTOM", pickerFrame, "BOTTOM", 0, 22)
    pickerFrame.footerText:SetText("Hover a card for spell details. Choose gives a tome; use the tome to learn the spell.")

    local veilButton = CreateFrame("Button", nil, pickerFrame, "UIPanelButtonTemplate")
    veilButton:SetSize(82, 22)
    veilButton:SetPoint("TOPLEFT", pickerFrame, "TOPLEFT", 14, -24)
    veilButton:SetText("Veil")
    veilButton:SetScript("OnClick", function()
        RenderRow("veil", "row1")
    end)

    local arcanistButton = CreateFrame("Button", nil, pickerFrame, "UIPanelButtonTemplate")
    arcanistButton:SetSize(92, 22)
    arcanistButton:SetPoint("LEFT", veilButton, "RIGHT", 6, 0)
    arcanistButton:SetText("Arcanist")
    arcanistButton:SetScript("OnClick", function()
        RenderRow("arcanist", "row1")
    end)
    local ruinButton = CreateFrame("Button", nil, pickerFrame, "UIPanelButtonTemplate")
    ruinButton:SetSize(72, 22)
    ruinButton:SetPoint("LEFT", arcanistButton, "RIGHT", 6, 0)
    ruinButton:SetText("Ruin")
    ruinButton:SetScript("OnClick", function()
        RenderRow("ruin", "row1")
    end)
    local ashButton = CreateFrame("Button", nil, pickerFrame, "UIPanelButtonTemplate")
    ashButton:SetSize(66, 22)
    ashButton:SetPoint("LEFT", ruinButton, "RIGHT", 6, 0)
    ashButton:SetText("Ash")
    ashButton:SetScript("OnClick", function()
        RenderRow("ash", "row1")
    end)
    local wardenButton = CreateFrame("Button", nil, pickerFrame, "UIPanelButtonTemplate")
    wardenButton:SetSize(82, 22)
    wardenButton:SetPoint("LEFT", ashButton, "RIGHT", 6, 0)
    wardenButton:SetText("Warden")
    wardenButton:SetScript("OnClick", function()
        RenderRow("warden", "row1")
    end)




    for i, rowKey in ipairs(rowOrder) do
        local rowButton = CreateFrame("Button", nil, pickerFrame, "UIPanelButtonTemplate")
        rowButton:SetSize(50, 20)
        rowButton:SetPoint("TOPLEFT", pickerFrame, "TOPLEFT", 14 + ((i - 1) * 54), -52)
        rowButton:SetText("Row " .. i)
        rowButton:SetScript("OnClick", function()
            RenderRow(activeDisciplineKey, rowKey)
        end)
    end

    local close = CreateFrame("Button", nil, pickerFrame, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", pickerFrame, "TOPRIGHT", -8, -8)

    RenderRow(activeDisciplineKey, activeRowKey)
    pickerFrame:Hide()
end

local function OpenPicker(disciplineKey, rowKey)
    activeDisciplineKey = disciplineKey or activeDisciplineKey or "veil"
    activeRowKey = rowKey or activeRowKey or "row1"

    if not pickerFrame then
        CreatePicker()
    end

    RenderRow(activeDisciplineKey, activeRowKey)
    pickerFrame:Show()
end

local function TogglePicker(disciplineKey, rowKey)
    if not pickerFrame then
        CreatePicker()
    end

    disciplineKey = disciplineKey or activeDisciplineKey or "veil"
    rowKey = rowKey or activeRowKey or "row1"

    if pickerFrame:IsShown() and disciplineKey == activeDisciplineKey and rowKey == activeRowKey then
        pickerFrame:Hide()
    else
        OpenPicker(disciplineKey, rowKey)
    end
end

local function NormalizeRow(msg)
    if msg == "row5" or msg == "5" then return "row5" end
    if msg == "row4" or msg == "4" then return "row4" end
    if msg == "row3" or msg == "3" then return "row3" end
    if msg == "row2" or msg == "2" then return "row2" end
    if msg == "row1" or msg == "1" or msg == "" then return "row1" end
    return nil
end

SLASH_LANTERNWAKEPICKER1 = "/lwpicker"
SLASH_LANTERNWAKEPICKER2 = "/lwp"
SlashCmdList["LANTERNWAKEPICKER"] = function(msg)
    msg = string.lower(msg or "")
    msg = string.gsub(msg, "^%s*(.-)%s*$", "%1")

    local first, second = string.match(msg, "^(%S+)%s*(.*)$")

    if first == "veil" or first == "arcanist" or first == "ruin" or first == "ash" or first == "warden" then
        local rowKey = NormalizeRow(second or "")
        if rowKey then
            TogglePicker(first, rowKey)
            return
        end
    end

    local rowKey = NormalizeRow(msg)
    if rowKey then
        TogglePicker(activeDisciplineKey or "veil", rowKey)
        return
    end

    Print("Use /lwp veil row1-5, /lwp arcanist row1-5, /lwp ruin row1-5, /lwp ash row1-5, or /lwp warden row1-5.")
end

Print("v1.0 Picker Polish loaded. Hover cards for spell details. Type /lwp veil, arcanist, ruin, ash, or warden row1.")








